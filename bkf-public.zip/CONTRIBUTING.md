# Contributing to BKF

We welcome contributions! Please follow the guidelines:
- Fork the repository
- Use clear commit messages
- Open a pull request with proper descriptions
