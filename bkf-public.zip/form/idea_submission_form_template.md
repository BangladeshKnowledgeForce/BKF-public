# BKF Idea Submission Form Template

Please answer the following:
- What is your idea?
- Why is it important for Bangladesh?
