# FAQ

**Q: Who can submit ideas?**
Anyone from Bangladesh.

**Q: Are ideas public?**
Only selected ideas will be publicly visible.