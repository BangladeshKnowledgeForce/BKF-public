# Sample BKF Telegram Bot Code

print('BKF bot running...')